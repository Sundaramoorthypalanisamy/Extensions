//
//  APIManager.swift
//  Assesment
//
//  Created by Jegan on 07/01/17.
//  Copyright © 2017 BitsOHacker. All rights reserved.
//

import UIKit
import Alamofire
typealias CallbackBlock = (Data?, Error?) -> Void
typealias ResponseBlock = (DataResponse<Any>, Int, Error?) -> Void
typealias ResponseBlocks = (DataResponse<String>, Int, Error?) -> Void
typealias UploadObject = (UploadRequest) -> Void

//enum Environment:Int{
//    case dev, stage, prod, demo
//}
enum Environment:Int{
    case log, cam, exp, pra
}
//enum RestBase:String{
//    
//    case dev = "http://182.75.225.213/ExpenseClaim/"
////    case stag = "http://192.168.1.128:9090/CohenAPI"
////    case prod = "http://192.168.1.128:9090/CohenAPI"
////    case demo = "http://192.168.1.128:9090/CohenAPI"
//}

enum MimeType:String{
    case jpeg = "image/jpeg"
    case jpg = "image/jpg"
    case png = "image/png"
    case video = "quicktime/video"
}

class MultiPart:NSObject{
    var data:Data?
    var fileName:String?
    var paramKey:String?
    var mimeType:String?
}

class APIManager: NSObject {
    
    //Base URL's & environment mode
    var prod,dev,stage,demo:String?
    
    var environment : Environment!
    var loaderStartBlock: ((Any) -> Any)?
    var loaderEndBlock: ((Any,Any) -> Void)?
    var networkNotReached: (() -> Void)?
    static let shared = APIManager()
    
    var session = URLSession.shared
    let configuration = URLSessionConfiguration.default
    var dataTaskManager:SessionManager?
    var uploadTaskManager:SessionManager?
    
    //Avoid basic init using () instead of sharedManager
    private override init() {
        super.init()
        self.initObjects()
    }
    
    //Initialize the instance variables
    func initObjects() -> Void {
        dataTaskManager = Alamofire.SessionManager(configuration: configuration)
        uploadTaskManager = Alamofire.SessionManager(configuration: URLSessionConfiguration.background(withIdentifier: Bundle.main.bundleIdentifier!))
    }
    
    
    //Append environment base with end url
    func appendBaseURL(restEnd : String) -> String {
        
        if (!restEnd.contains("http://") && !restEnd.contains("https://")) {
            switch environment{
            case .log?:
           
             return baseURL + restEnd
                
            case .cam?:
                return camerabaseURL + restEnd
                
            case .exp?:
                return expensebaseURL + restEnd
            case .pra?:
                return PRbaseURL + restEnd
            case .none:
                 return baseURL + restEnd
            case .some(_):
                 return baseURL + restEnd
            }
        }
        
        return restEnd
    }
    
    
    func getHttpRequest(url: String, httpMethod: HTTPMethod, params: Parameters?, headers:HTTPHeaders?) -> DataRequest{
        
        //Append base url
        let restEnd = self.appendBaseURL(restEnd: url)
        
        //Make Http request
        return (dataTaskManager?.request(restEnd, method: httpMethod, parameters: params, encoding: URLEncoding.default, headers: headers!))!
    }
    
    func sendHttpRequest(request : DataRequest, responseBlock:@escaping ResponseBlock, showLoaderOn:UIView?) -> DataRequest? {
        
        
            var loaderObj:Any?
            //Check need to show a loader
            if (loaderStartBlock != nil && showLoaderOn != nil){
                loaderObj = loaderStartBlock!(showLoaderOn!)
            }
            
            //Make Http request
            let request = request.responseJSON { response in
                
                switch response.result {
                case .success:
                    responseBlock(response, (response.response?.statusCode)!, nil)
                case .failure(let error):
                    responseBlock(response, (response.response?.statusCode)!, error)
                    print(error)
                }
                
                //Check need to hide the loader
                if (self.loaderEndBlock != nil && showLoaderOn != nil && loaderObj != nil){
                    self.loaderEndBlock!(loaderObj!,showLoaderOn!)
                }
            };
  
            return request;
    }
    
    //Send Data tasks using AFNetworking
    func sendHTTPRequest(url: String, headers:HTTPHeaders?, httpMethod: HTTPMethod, params: Parameters?, showLoaderOn:UIView?, responseBlock: @escaping ResponseBlock) -> DataRequest? {
      
        //Append base url
            let restEnd = self.appendBaseURL(restEnd: url)
            var loaderObj:Any?
            //Check need to show a loader
            if (loaderStartBlock != nil && showLoaderOn != nil){
                loaderObj = loaderStartBlock!(showLoaderOn!)
            }
            print("<<<<<<<<<<<<<< Request >>>>>>>>>>>>>>>>")
            print("URL:\(restEnd)")
            print("BODY:\(params as Any)")
            print("BODY4:\(params as Any)")
            //Make Http request
            let request = dataTaskManager?.request(restEnd, method: httpMethod, parameters: params, encoding: URLEncoding.default, headers: headers).responseJSON { response in
                
                switch response.result
                {
                case .success:
                    print("BODY1:\(params as Any)")
                    let statusCode = (response.response?.statusCode)!
                    print("<<<<<<<<<<<<<< Response (\(statusCode)) >>>>>>>>>>>>>>>>")
                  //  print(response)
                   
                    responseBlock(response, statusCode, nil)
                case .failure(let error):
                    print("BODY2:\(params as Any)")
                    if let responseValue = response.response{
                        let statusCode = responseValue.statusCode
                        print("<<<<<<<<<<<<<< Error (\(statusCode)) >>>>>>>>>>>>>>>>")
                        print(error)
                        responseBlock(response, statusCode, error)
                    }
                    else{
                        print("BODY3:\(params as Any)")
                        print(error)
                        responseBlock(response, 0, error)
                    }
                }
                
                //Check need to hide the loader
                if (self.loaderEndBlock != nil && showLoaderOn != nil && loaderObj != nil){
                    self.loaderEndBlock!(loaderObj!,showLoaderOn!)
                }
            };
            return request!;
       
    }
    
    
    func sendMultiPartRequest(url: String, httpHeaders: HTTPHeaders?, httpMethod: HTTPMethod, params: Parameters?, mulitparts: NSMutableArray, responseBlock: @escaping ResponseBlocks, uploadObject: @escaping UploadObject) {
        
            //Append base url
            let restEnd = self.appendBaseURL(restEnd: url)
            
            print("<<<<<<<<<<<<<< Request >>>>>>>>>>>>>>>>")
            print("URL:\(restEnd)")
            print("BODY:\(params as Any)")
            print("BODY6:\(params as Any)")
            uploadTaskManager?.upload(
                multipartFormData: { multipartFormData in
                    
                    //Append file parts
                    for multiPartValue in mulitparts{
                        let multiPart:MultiPart = multiPartValue as! MultiPart
                        multipartFormData.append(multiPart.data!, withName: multiPart.paramKey!, fileName: multiPart.fileName!, mimeType: multiPart.mimeType!)
                    }
                    
                    //Append form fields
                    if(params != nil){
                        for (key, value) in params!{
                            multipartFormData.append("\(value)".data(using: .utf8)!, withName: key)
                        }
                    }
            },
                to: restEnd,
                method: httpMethod,
                headers: httpHeaders,
                encodingCompletion: { encodingResult in
                    switch encodingResult {
                    case .success(let upload, _, _):
                        
                        uploadObject(upload)
                        
                        upload.responseString(completionHandler: { (responseString) in
                            print(responseString)
                            responseBlock(responseString, 200, nil)
                        })
                        
                        
                        /*upload.responseJSON { response in
                            
                            let statusCode = (response.response?.statusCode)!
                            
                            switch response.result {
                            case .success:
                                print("<<<<<<<<<<<<<< Response (\(statusCode)) >>>>>>>>>>>>>>>>")
                                print(response)
                                responseBlock(response, statusCode, nil)
                            case .failure(let error):
                                print("<<<<<<<<<<<<<< Error (\(statusCode)) >>>>>>>>>>>>>>>>")
                                print(error)
                                responseBlock(response, statusCode, error)
                            }
                        }
                        */
                                                
                    case .failure(let encodingError):
                        print(encodingError)
                    }
            }
            )
        }
    
}
