//
//  Utils.swift
//  SwiftCodeBase
//
//  Created by Prabakaran on 5/4/17.
//  Copyright © 2017 CodeBase. All rights reserved.
//

import UIKit


class UtilsManager: NSObject {
    
    static let shared = UtilsManager()
    
    //Avoid basic init using () instead of sharedManager
    private override init() {
        super.init()
        self.initObjects()
    }
    
    //Initialize the instance variables
    func initObjects() -> Void {
        //UtilsManager.monitorNetwork()
    }
    
// MARK: - Network
//    static var networkChangedBlock: ((Bool) -> Void)?
//    static var reachability = Reachability()!
//    static var isNetworkReached:Bool{
//        get{
//            if UtilsManager.reachability.currentReachabilityStatus == .notReachable{
//                RequestManager.shared.NetworkNotReached()
//                return false
//            }
//            else{
//                return true
//            }
//        }
//    }
//
//    static func monitorNetwork() {
//
//        reachability.whenReachable = { reachability in
//            // this is called on a background thread, but UI updates must
//            // be on the main thread, like this:
//            DispatchQueue.main.async {
//                if(UtilsManager.networkChangedBlock != nil){
//                    UtilsManager.networkChangedBlock!(true)
//                }
//            }
//        }
//
//        reachability.whenUnreachable = { reachability in
//            // this is called on a background thread, but UI updates must
//            // be on the main thread, like this:
//            DispatchQueue.main.async {
//                if(UtilsManager.networkChangedBlock != nil){
//                    UtilsManager.networkChangedBlock!(false)
//                }
//            }
//        }
//
//        do {
//            try reachability.startNotifier()
//        } catch {
//            print("Unable to start notifier")
//        }
//    }
    
// MARK: - Application
    static var appName: String{
        return Bundle.main.infoDictionary?["CFBundleName"] as! String
    }
    
    static var appVersion:String{
        return Bundle.main.infoDictionary?["CFBundleShortVersionString"] as! String
    }
    
    static var appBuildVersion:String{
        return Bundle.main.infoDictionary?["CFBundleVersion"] as! String
    }
    
    

    

    func ReadTextFrom(fileName: String) -> String {
        
        if let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            let fileURL = dir.appendingPathComponent(fileName)
            //reading
            do {
                let text2 = try String(contentsOf: fileURL, encoding: .utf8)
                return text2
            }
            catch {
                /* error handling here */
                
            }
        }
        return ""
    }
    
    func WriteTextTo(fileName: String, content: String) -> Bool{
        if let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            
            let fileURL = dir.appendingPathComponent(fileName)
            
            //writing
            do {
                try content.write(to: fileURL, atomically: false, encoding: .utf8)
            }
            catch {
                return false
            }
            return true
        }
        return false
    }
    
}

