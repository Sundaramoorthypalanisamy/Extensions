//
//  TNMBExtension.swift
//  TNMBanking
//
//  Created by Prabakaran on 28/06/18.
//  Copyright © 2018 MyMin Solutions. All rights reserved.
//

import Foundation
import UIKit


extension String {
    var digits: String {
        return components(separatedBy: CharacterSet.decimalDigits.inverted)
            .joined()
    }
}

extension UIView {
    
    func addShadow(color: UIColor) {
        layer.cornerRadius = 1
        layer.masksToBounds = false
        layer.shadowColor = color.cgColor
        layer.shadowOffset = CGSize(width: 0.5, height: 4)
        layer.shadowOpacity = 0.5
        layer.shadowRadius = 5.0
    }
    
    func addBorderColor(color: UIColor, width: CGFloat){
        self.layer.borderColor = color.cgColor
        self.layer.borderWidth = width
        self.layer.masksToBounds = true
    }
    
    func addRoundedCorner()
    {
        self.layoutIfNeeded()
        self.layer.cornerRadius = self.frame.height / 2
        self.clipsToBounds = true
    }
    func addCornerRadius(radious: CGFloat){
        self.layoutIfNeeded()
        self.layer.cornerRadius = radious
        self.clipsToBounds = true
    }
}
//0096FF

extension UIColor {
    
    func AppBlue() -> UIColor
    {
        return UIColor.init(hex: "0096FF")
    }
    
    convenience init(hex: String) {
        
        let scanner = Scanner(string: hex)
        scanner.scanLocation = 0
        
        var rgbValue: UInt64 = 0
        
        scanner.scanHexInt64(&rgbValue)
        
        let r = (rgbValue & 0xff0000) >> 16
        let g = (rgbValue & 0xff00) >> 8
        let b = rgbValue & 0xff
        
        self.init(
            red: CGFloat(r) / 0xff,
            green: CGFloat(g) / 0xff,
            blue: CGFloat(b) / 0xff, alpha: 1
        )
    }
}

extension UINavigationController {
    
    public func presentTransparentNavigationBar()
    {
        self.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        self.navigationBar.isTranslucent = true
        self.navigationBar.shadowImage = UIImage()
        setNavigationBarHidden(false, animated: true)
    }
    

    
}

extension UITextField{
    
    func addLeftView(size: CGFloat){
        self.leftViewMode = .always
        self.leftView = UIView(frame: CGRect(x: 0, y: 0, width: size, height: self.frame.size.height))
    }
    func addRightView(size: CGFloat){
        self.rightViewMode = .always
        self.rightView = UIView(frame: CGRect(x: 0, y: 0, width: size, height: self.frame.size.height))
    }
    
    func addBottomBorderColor(color: UIColor)
    {
        self.borderStyle = UITextBorderStyle.none;
        let border = CALayer()
        let width = CGFloat(1.0)
        border.frame = CGRect(x: 0, y: self.frame.size.height - width,   width:  self.frame.size.width, height: self.frame.size.height)
        border.borderWidth = width
        border.borderColor = color.cgColor
        self.layer.addSublayer(border)
        self.layer.masksToBounds = true
    }
}
