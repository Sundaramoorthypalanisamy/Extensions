//
//  DBManager.swift
//  TNMBanking
//
//  Created by Prabakaran on 17/07/18.
//  Copyright © 2018 MyMin Solutions. All rights reserved.
//

import Foundation
import SQLite3


// DB SETUP
let DBName = "TNMB"
let DBType = "sqlite"


class DBManager: NSObject {
    
    static let shared = DBManager()
    var db: OpaquePointer?
    
    func getDBPath() -> String{
        let documentsUrl = FileManager.default.urls(for: .documentDirectory,
                                            in: .userDomainMask)
        let dbpath = documentsUrl.first!.appendingPathComponent("TNMB.sqlite")
        return String(describing: dbpath)
    }
    
    //Avoid basic init using () instead of sharedManager
    private override init() {
        super.init()
        self.copyDatabaseIfNeeded()
    }
    
    
    func copyDatabaseIfNeeded() {
        // Move database file from bundle to documents folder
        
        let fileManager = FileManager.default
        let documentsUrl = fileManager.urls(for: .documentDirectory,
                                            in: .userDomainMask)
        
        guard documentsUrl.count != 0 else {
            return // Could not find documents URL
        }
        
        let finalDatabaseURL = documentsUrl.first!.appendingPathComponent("TNMB.sqlite")
        if !( (try? finalDatabaseURL.checkResourceIsReachable()) ?? false) {
            print("DB does not exist in documents folder")
            
            let documentsURL = Bundle.main.resourceURL?.appendingPathComponent("TNMB.sqlite")
            
            do {
                try fileManager.copyItem(atPath: (documentsURL?.path)!, toPath: finalDatabaseURL.path)
            } catch let error as NSError {
                print("Couldn't copy file to final location! Error:\(error.description)")
            }
        } else {
            print("Database file found at path: \(finalDatabaseURL.path)")
        }
        
    }
    
    
    
    
    func GetAllUsers() -> NSArray? {
        //
        let users = NSMutableArray.init()
        let dbPath = DBManager.shared.getDBPath()
        let queryString = "select fld_id,fld_name,fld_email,fld_accountnumber,fld_passcode,fld_balance from tbl_users"
        
        var stmt:OpaquePointer?
        if sqlite3_open(dbPath, &db) == SQLITE_OK {
            if sqlite3_prepare(db, queryString, -1, &stmt, nil) == SQLITE_OK{
                
                while(sqlite3_step(stmt) == SQLITE_ROW){
                    
                    let i_d = sqlite3_column_int(stmt, 0)
                    let name = String(cString: sqlite3_column_text(stmt, 1))
                    let email = String(cString: sqlite3_column_text(stmt, 2))
                    let accountnumber = String(cString: sqlite3_column_text(stmt, 3))
                    let passcode = String(cString: sqlite3_column_text(stmt, 4))
                    let balance = sqlite3_column_int(stmt, 5)
                    
                    let user = User.init(id: Int(i_d), name: name, email: email, accountnumber: accountnumber, passcode: passcode, balance: Int(balance))
                    users.add(user)
                }
            }else{
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("error preparing query: \(errmsg)")
            }
            sqlite3_finalize(stmt)
            sqlite3_close(db)
        }else{
            print("error opening database")
        }
        return users
    }
    
    func GetUserInfo(accountnumber: String) -> User? {
        //
        var userinfo: User!
        let dbPath = DBManager.shared.getDBPath()
        let queryString = "select fld_id,fld_name,fld_email,fld_accountnumber,fld_passcode,fld_balance from tbl_users where fld_accountnumber = \(String(describing: accountnumber))"
        
        var stmt:OpaquePointer?
        if sqlite3_open(dbPath, &db) == SQLITE_OK {
            if sqlite3_prepare(db, queryString, -1, &stmt, nil) == SQLITE_OK{
                
                while(sqlite3_step(stmt) == SQLITE_ROW){
                    
                    let i_d = sqlite3_column_int(stmt, 0)
                    let name = String(cString: sqlite3_column_text(stmt, 1))
                    let email = String(cString: sqlite3_column_text(stmt, 2))
                    let accountnumber = String(cString: sqlite3_column_text(stmt, 3))
                    let passcode = String(cString: sqlite3_column_text(stmt, 4))
                    let balance = sqlite3_column_int(stmt, 5)
                    
                    userinfo = User.init(id: Int(i_d), name: name, email: email, accountnumber: accountnumber, passcode: passcode, balance: Int(balance))
                }
            }else{
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("error preparing query: \(errmsg)")
            }
            sqlite3_finalize(stmt)
            sqlite3_close(db)
        }else{
            print("error opening database")
        }
        return userinfo
    }
    
    func TansferFund(from: NSString, to: NSString, amount: NSString) -> Bool
    {
        //insert into tbl_transactions  (fld_sender,fld_receiver, fld_amount, fld_date) values ( "123", "321", "10","today")
        
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy hh:mm a"
        let datetime = formatter.string(from: NSDate() as Date) as NSString
        var success:Bool = false
        
        var stmt:OpaquePointer?
        let dbPath = DBManager.shared.getDBPath()
        let queryString = "INSERT INTO tbl_transactions (fld_sender, fld_receiver, fld_amount, fld_date) VALUES (?, ?, ?, ?);"

        if sqlite3_open(dbPath, &db) == SQLITE_OK {
            if sqlite3_prepare_v2(db, queryString, -1, &stmt, nil) == SQLITE_OK
            {
                sqlite3_bind_text(stmt, 1, from.utf8String, -1, nil)
                sqlite3_bind_text(stmt, 2, to.utf8String, -1, nil)
                sqlite3_bind_text(stmt, 3, amount.utf8String, -1, nil)
                sqlite3_bind_text(stmt, 4, datetime.utf8String, -1, nil)
                
                if sqlite3_step(stmt) == SQLITE_DONE {
                    print("Successfully inserted row.")
                    success = true
                } else {
                    print("Could not insert row.")
                }
            } else {
                print("INSERT statement could not be prepared.")
            }
            // 5
            sqlite3_finalize(stmt)
            sqlite3_close(db)
        }
        return success
    }
    
    func GetTransactionsFor(accnumber: NSString) -> NSArray
    {
        //select * from tbl_transactions where fld_sender="87654323" or fld_receiver = "87654323"
        let transactions = NSMutableArray.init()
        let dbPath = DBManager.shared.getDBPath()
        let queryString = "select fld_id,fld_sender,fld_receiver,fld_amount,fld_date from tbl_transactions where fld_sender=? or fld_receiver = ?"
        
        var stmt:OpaquePointer?
        if sqlite3_open(dbPath, &db) == SQLITE_OK {
            if sqlite3_prepare(db, queryString, -1, &stmt, nil) == SQLITE_OK
            {
                sqlite3_bind_text(stmt, 1, accnumber.utf8String, -1, nil)
                sqlite3_bind_text(stmt, 2, accnumber.utf8String, -1, nil)
                
                while(sqlite3_step(stmt) == SQLITE_ROW){
                    
                    let i_d = sqlite3_column_int(stmt, 0)
                    let sender = String(cString: sqlite3_column_text(stmt, 1))
                    let receiver = String(cString: sqlite3_column_text(stmt, 2))
                    let amount = String(cString: sqlite3_column_text(stmt, 3))
                    let datetime = String(cString: sqlite3_column_text(stmt, 4))
                    let transaction = Statement.init(id: Int(i_d), from: sender, to: receiver, amount: amount, date: datetime)
                    transactions.add(transaction)
                }
            }else{
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("error preparing query: \(errmsg)")
            }
            sqlite3_finalize(stmt)
            sqlite3_close(db)
        }else{
            print("error opening database")
        }
        return transactions
    }
    
    
    
    func UpdateBalance(userid: Int, amount: Int) -> Bool
    {
        var success:Bool = false
        
        var stmt:OpaquePointer?
        let dbPath = DBManager.shared.getDBPath()
        let queryString = "UPDATE tbl_users SET fld_balance = ? WHERE fld_Id = ?"
        
        if sqlite3_open(dbPath, &db) == SQLITE_OK {
            if sqlite3_prepare_v2(db, queryString, -1, &stmt, nil) == SQLITE_OK
            {
                sqlite3_bind_int(stmt, 1, Int32(amount))
                sqlite3_bind_int(stmt, 2, Int32(userid))
                
                if sqlite3_step(stmt) == SQLITE_DONE {
                    print("Successfully Updated row.")
                    success = true
                } else {
                    print("Could not update row.")
                }
            } else {
                print("Update statement could not be prepared.")
            }
            // 5
            sqlite3_finalize(stmt)
            sqlite3_close(db)
        }
        return success
    }
    
//    func getPortfolioList() -> [Portfolio] {
//
//        let dbPath = UtilsManager.shared.getDBPath()
//        let queryString = "SELECT _id, Name AS Title, Description AS Text, IconUrl, ConfigStr, PortfolioType from Portfolio WHERE StatusIn = 'Y'"
//
//        var stmt:OpaquePointer?
//        if sqlite3_open(dbPath, &db) == SQLITE_OK {
//            if sqlite3_prepare(db, queryString, -1, &stmt, nil) == SQLITE_OK{
//
//                while(sqlite3_step(stmt) == SQLITE_ROW){
//
//                    let id = sqlite3_column_int(stmt, 0)
//                    let name = String(cString: sqlite3_column_text(stmt, 1))
//                    let desc = String(cString: sqlite3_column_text(stmt, 2))
//                    let icon = String(cString: sqlite3_column_text(stmt, 3))
//                    let config = String(cString: sqlite3_column_text(stmt, 4))
//                    let type = sqlite3_column_int(stmt, 5)
//
//                    let item = Portfolio.init(id: Int(id), title: String(describing: name), desc: String(describing: desc), iconurl: String(describing: icon), type: Int(type))
//                    array.append(item)
//                }
//            }else{
//                let errmsg = String(cString: sqlite3_errmsg(db)!)
//                print("error preparing query: \(errmsg)")
//            }
//        }else{
//            print("error opening database")
//        }
//        return array
//    }
//
//    func getTileListWith(portfolio:Portfolio) -> [Tile] {
//
//        var array = [Tile]()
//
//        let dbPath = UtilsManager.shared.getDBPath()
//        let queryString = "SELECT _id, Name, Description, ParentTileId, IconUrl, ConfigStr, TargetTbl, TileType, LevelNr FROM Tile WHERE StatusIn = 'Y' AND PortfolioId = \(String(describing: portfolio.id!)) ORDER BY OrderNr"
//
//        var stmt:OpaquePointer?
//        if sqlite3_open(dbPath, &db) == SQLITE_OK {
//            if sqlite3_prepare(db, queryString, -1, &stmt, nil) == SQLITE_OK{
//
//                while(sqlite3_step(stmt) == SQLITE_ROW){
//
//                    let id  = sqlite3_column_int(stmt, 0)
//                    let name = String(cString: sqlite3_column_text(stmt, 1))
//                    let desc = String(cString: sqlite3_column_text(stmt, 2))
//                    let parentid  = sqlite3_column_int(stmt, 3)
//                    let iconurl = String(cString: sqlite3_column_text(stmt, 4))
//                    let targettbl = String(cString: sqlite3_column_text(stmt, 6))
//                    let tiletype  = sqlite3_column_int(stmt, 7)
//                    let level  = sqlite3_column_int(stmt, 8)
//
//
//                    let item = Tile.init(id: Int(id), name: name, desc: desc, parentid: Int(parentid), iconurl: iconurl, targettbl: targettbl, tiletype: Int(tiletype), level: Int(level))
//                    array.append(item)
//                }
//            }else{
//                let errmsg = String(cString: sqlite3_errmsg(db)!)
//                print("error preparing query: \(errmsg)")
//            }
//        }else{
//            print("error opening database")
//        }
//        return array
//    }
//
//
//    func getListItemsWith(tile: Tile) -> NSArray {
//
//        let lists = NSMutableArray.init()
//
//        var queryString: String!
//        if self.selected_Portfolio.id == 1 {
//            queryString = "SELECT FileName,LastWorkedDt FROM <tbl>"
//        }else{
//            queryString = "SELECT Workedon, IFNULL(#Records, 0) FROM <tbl>"
//        }
//        queryString = queryString.replacingOccurrences(of: "<tbl>", with: tile.targettbl!)
//
//
//        let dbPath = UtilsManager.shared.getDBPath()
//
//        var stmt:OpaquePointer?
//        if sqlite3_open(dbPath, &db) == SQLITE_OK {
//            if sqlite3_prepare(db, queryString, -1, &stmt, nil) == SQLITE_OK{
//
//                while(sqlite3_step(stmt) == SQLITE_ROW){
//
//                    let name = String(cString: sqlite3_column_text(stmt, 0))
//                    let desc = String(cString: sqlite3_column_text(stmt, 1))
//
//                    let myDictOfDict: NSDictionary = [
//                        "title" : name,
//                        "desc" : desc,
//                        ]
//                    lists.add(myDictOfDict)
//                }
//            }else{
//                let errmsg = String(cString: sqlite3_errmsg(db)!)
//                print("error preparing query: \(errmsg)")
//            }
//        }else{
//            print("error opening database")
//        }
//        return lists
//    }
//
//    func getGridItemsWith(tile: Tile) -> NSArray {
//
//        let lists = NSMutableArray.init()
//
//        var queryString: String!
//        if self.selected_Portfolio.id == 1 {
//            queryString = "SELECT TableName,Type FROM <tbl>"
//        }else{
//            queryString = "SELECT Workedon, IFNULL(#Records, 0) FROM <tbl>"
//        }
//        queryString = queryString.replacingOccurrences(of: "<tbl>", with: tile.targettbl!)
//
//        let dbPath = UtilsManager.shared.getDBPath()
//
//        var stmt:OpaquePointer?
//        if sqlite3_open(dbPath, &db) == SQLITE_OK {
//            if sqlite3_prepare(db, queryString, -1, &stmt, nil) == SQLITE_OK{
//
//                while(sqlite3_step(stmt) == SQLITE_ROW){
//
//                    let name = String(cString: sqlite3_column_text(stmt, 0))
//                    let desc = String(cString: sqlite3_column_text(stmt, 1))
//
//                    let myDictOfDict: NSDictionary = [
//                        "title" : name,
//                        "desc" : desc,
//                        ]
//                    lists.add(myDictOfDict)
//                }
//            }else{
//                let errmsg = String(cString: sqlite3_errmsg(db)!)
//                print("error preparing query: \(errmsg)")
//            }
//        }else{
//            print("error opening database")
//        }
//        return lists
//    }
//
//
//    func getChartItemsWith(tile: Tile) -> NSArray {
//
//        let lists = NSMutableArray.init()
//        //var queryString = "PRAGMA table_info(<tbl>)"
//        var queryString = "SELECT * FROM (<tbl>)"
//        queryString = queryString.replacingOccurrences(of: "<tbl>", with: tile.targettbl!)
//        let dbPath = UtilsManager.shared.getDBPath()
//
//        var stmt:OpaquePointer?
//        if sqlite3_open(dbPath, &db) == SQLITE_OK {
//            if sqlite3_prepare(db, queryString, -1, &stmt, nil) == SQLITE_OK{
//
//                while(sqlite3_step(stmt) == SQLITE_ROW){
//
//                    let name = String(cString: sqlite3_column_text(stmt, 0))
//                    // let value = String(cString: sqlite3_column_text(stmt, 1))
//                    let value  = sqlite3_column_int(stmt, 1)
//
//                    let myDictOfDict: NSDictionary = [
//                        "title" : name,
//                        "value" : value,
//                        ]
//                    lists.add(myDictOfDict)
//                }
//            }else{
//                let errmsg = String(cString: sqlite3_errmsg(db)!)
//                print("error preparing query: \(errmsg)")
//            }
//        }else{
//            print("error opening database")
//        }
//        return lists
//    }
//
//
//
//
//
//
//
//
//    func getAllColumnsNameFrom(table: String) ->NSMutableArray {
//
//        let lists = NSMutableArray.init()
//        var queryString = "PRAGMA table_info(<tbl>)"
//        queryString = queryString.replacingOccurrences(of: "<tbl>", with: table)
//        let dbPath = UtilsManager.shared.getDBPath()
//
//        var stmt:OpaquePointer?
//        if sqlite3_open(dbPath, &db) == SQLITE_OK {
//            if sqlite3_prepare(db, queryString, -1, &stmt, nil) == SQLITE_OK{
//                while(sqlite3_step(stmt) == SQLITE_ROW){
//                    let name = String(cString: sqlite3_column_text(stmt, 1))
//                    lists.add(name)
//                }
//            }else{
//                let errmsg = String(cString: sqlite3_errmsg(db)!)
//                print("error preparing query: \(errmsg)")
//            }
//        }else{
//            print("error opening database")
//        }
//        return lists
//    }
    
    
}
